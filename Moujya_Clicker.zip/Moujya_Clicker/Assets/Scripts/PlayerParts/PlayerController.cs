﻿using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [SerializeField] private AttackCollider attackCollider = null;
    private float PlayerRot = 0.0f;

    // Update is called once per frame
    private void Update()
    {
        // 攻撃しているときは動けません
        if (!attackCollider.bAttackFrameIsBusy)
        {
            #region プレイヤーの向き操作(WASD)

            if (Input.GetKey(KeyCode.W))
            {
                PlayerRot = 0.0f;
                this.transform.rotation = Quaternion.Euler(0.0f, PlayerRot, 0.0f);
            }
            if (Input.GetKey(KeyCode.D))
            {
                PlayerRot = 90.0f;
                this.transform.rotation = Quaternion.Euler(0.0f, PlayerRot, 0.0f);
            }
            if (Input.GetKey(KeyCode.S))
            {
                PlayerRot = 180.0f;
                this.transform.rotation = Quaternion.Euler(0.0f, PlayerRot, 0.0f);
            }
            if (Input.GetKey(KeyCode.A))
            {
                PlayerRot = 270.0f;
                this.transform.rotation = Quaternion.Euler(0.0f, PlayerRot, 0.0f);
            }

            #endregion プレイヤーの向き操作(WASD)
        }
    }
}